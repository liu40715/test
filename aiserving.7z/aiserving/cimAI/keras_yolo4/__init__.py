from cimUtil.log import Log as log
from ..models import Model
from .utils.utils import get_yolo_boxes
from .utils.bbox import draw_boxes
from .nets.yolo import yolo_body
from PIL import Image
import os, json, cv2, numpy, io, base64, math


# 環境偵測 - todo
try:
  # arm64 container
  import tensorflow.python.keras as ks
  import tensorflow as tf
except:
  # amd64 container
  import keras as ks


class KerasYolo4():
  def __init__(self, name):
    self.name = name
    self.region = None
    self.model = None
    self.graph = None
    self.session = None
    self.anchors = None
    self.classes = None
    self.colors = None
    self.net_h = None
    self.net_w = None
    self.obj_thresh = 0.3
    self.nms_thresh = 0.3

    try:
      # init session
      # https://ithelp.ithome.com.tw/articles/10214735
      # https://blog.csdn.net/shuibuzhaodeshiren/article/details/84239033
      self.graph = tf.Graph()
      self.session = tf.compat.v1.Session( 
        graph = self.graph,
        config = tf.compat.v1.ConfigProto(
          # device_count = {'GPU': 1},
          # gpu_options = tf.compat.v1.GPUOptions(
          #   allow_growth = True,
          # ),
          # intra_op_parallelism_threads = 1,
          allow_soft_placement = True,
        )
      )
    except:
      pass

  def __del__(self):
    pass

  def _box2Data(self, boxes, labels, obj_thresh):
    data = []
    for box in boxes:
      d = {}
      for i in range(len(labels)):
        if box.classes[i] > obj_thresh:
          d['label'] = labels[i]
          d['score'] = round(box.get_score().item(), 4)
          d['x-min'] = box.xmin
          d['y-min'] = box.ymin
          d['x-max'] = box.xmax
          d['y-max'] = box.ymax
          data.append(d)
          break
    return data

  def load(self, basePath):
    modelPath = os.path.join(basePath, 'model.h5')
    infoPath = os.path.join(basePath, 'model.json')

    # check necessary files
    if not os.path.exists(modelPath): 
      log.log('file not exist: {}'.format(modelPath))
      return Model.State.NotExist
    if not os.path.exists(infoPath): 
      log.log('file not exist: {}'.format(infoPath))
      return Model.State.NotExist

    # load info
    try:
      with open(infoPath, 'r') as f: 
        conf = json.load(f)
        self.anchors = conf['anchors'] # necessary
        self.classes = conf['classes'] # necessary
        self.colors = conf['colors'] if 'colors' in conf else self.colors # BGR color
        self.net_h = conf['net_h'] if 'net_h' in conf else self.net_h
        self.net_w = conf['net_w'] if 'net_w' in conf else self.net_w
        self.obj_thresh = conf['obj_thresh'] if 'obj_thresh' in conf else self.obj_thresh
        self.nms_thresh = conf['nms_thresh'] if 'nms_thresh' in conf else self.nms_thresh
      log.log('{} loaded'.format(infoPath))
    except Exception as e:
      log.log('{} load fail, {}'.format(infoPath, e))
      return Model.State.LoadFail

    # load model
    try:
      if self.graph:
        with self.graph.as_default():
          with self.session.as_default():
            self.model = yolo_body([None, None, 3], [[6, 7, 8], [3, 4, 5], [0, 1, 2]], len(self.classes))
            self.model.load_weights(modelPath)
      else:
        self.model = yolo_body([None, None, 3], [[6, 7, 8], [3, 4, 5], [0, 1, 2]], len(self.classes))
        self.model.load_weights(modelPath)

      log.log('{} loaded'.format(modelPath))
      return Model.State.Loaded
    except Exception as e:
      log.log('{} load fail: {}'.format(modelPath, e))
      return Model.State.LoadFail
  
   
  def predict(self, imageFile):
    net_h = None
    net_w = None
    try:
      image = Image.open(imageFile)
      image_np = numpy.array(image)
      img_bgr = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)
      img_bgr = cv2.resize(img_bgr, (608, 608), interpolation=cv2.INTER_AREA)
      if self.net_h is None or self.net_w is None: # config 內沒設定則用輸入圖片的大小決定        
        net_h = net_w = math.floor(min(img_bgr.shape[1], img_bgr.shape[0]) / 32) * 32
        log.log('model({}), imageSize({}x{}), networkSize({}x{}) reference from input image'.format(self.name, img_bgr.shape[1], img_bgr.shape[0], net_w, net_h))
      else:
        net_h, net_w = self.net_h, self.net_w
        log.log('model({}), imageSize({}}x{}), networkSize({}x{) reference from configuration'.format(self.name, img_bgr.shape[1], img_bgr.shape[0], net_w, net_h))
      
      if self.graph:
        with self.graph.as_default():
          with self.session.as_default():
            boxes = get_yolo_boxes(self.model, [img_bgr], net_h, net_w, self.anchors, self.obj_thresh, self.nms_thresh)[0]
            pre_img = draw_boxes(img_bgr, boxes, self.classes, self.obj_thresh, colors=self.colors)

      else:
        boxes = get_yolo_boxes(self.model, [img_bgr], net_h, net_w, self.anchors, self.obj_thresh, self.nms_thresh)[0]
        pre_img = draw_boxes(img_bgr, boxes, self.classes, self.obj_thresh, colors=self.colors)
      pre_img = cv2.resize(pre_img, (image_np.shape[1], image_np.shape[0]), interpolation=cv2.INTER_AREA)
      # cv2.imwrite("666.jpg",pre_img)
      pre_img = cv2.cvtColor(pre_img, cv2.COLOR_BGR2RGB)
      buffered = cv2.imencode('.jpg', pre_img)[1].tobytes()
      encoded_string = base64.b64encode(buffered).decode('utf8')
      return ['ok', str(encoded_string), self._box2Data(boxes, self.classes, self.obj_thresh)]      
    except Exception as e:
      return [log.log('{}'.format(e)), None, None]

from cimUtil.log import Log as log
from enum import Enum
import os, threading, queue
import gc # todo


class Model:
  class State(Enum):
    NotExist = 'model not exist'
    Queuing = 'model queuing'
    Loading = 'model loading'
    Loaded = 'model loaded'
    LoadFail = 'model load fail'
    NotSupport = 'not support model type'


class Models():
  def __init__(self):
    # private variable
    self._model = {}
    self._loaderLock = threading.Lock()
    self._loaderQueue = queue.Queue()

    # thread
    threading.Thread(target=self._loader, daemon=True).start()


  def __del__(self):
    pass


  #---------------------------------------------------------------------------
  # private function - common
  #---------------------------------------------------------------------------
  def _loader(self):
    while True:
      model = None
      dummy = None

      # get queue job
      job = self._loaderQueue.get()
      key = job['key']
      log.log('dequeue {}'.format(key))
      self._model[key]['state'] = Model.State.Loading
      if job['type'] == 'keras-yolo3':
        try:
          KerasYolo3 # check if loaded
        except:
          from .keras_yolo3 import KerasYolo3
        model = KerasYolo3(key)
        dummy = os.path.join(job['base'], job['type'], 'dummy.jpg')
      elif job['type'] == 'keras-yolo4':
        try:
          KerasYolo4 # check if loaded
        except:
          from .keras_yolo4 import KerasYolo4
        model = KerasYolo4(key)
        dummy = os.path.join(job['base'], job['type'], 'dummy.jpg')
###################測試中...##################
      elif job['type'] == 'keras-cnn':
        try:
          CNN # check if loaded
        except:
          from .keras_cnn import CNN
        model = CNN(key)

      elif job['type'] == 'keras-face':
        try:
          Keras_face # check if loaded
        except:
          from .keras_face import Kerasface
        model = Kerasface(key) 
      elif job['type'] == 'oarriaga' and job['name'] == 'face-classification':
        try:
          OarriagaFaceClassification
        except:
          from .oarriaga.face_classification import OarriagaFaceClassification
        model = OarriagaFaceClassification(key)

      elif job['type'] == 'tf-test':
        try:
          tf_test # check if loaded
        except:
          from .tf_test import CT
        model = CT(key) 
      elif job['type'] == 'tf-test2':
        try:
          tf_test2 # check if loaded
        except:
          from .tf_test2 import OP
        model = OP(key)

      elif job['type'] == 'tf-mcnn':
        try:
          tf_mcnn # check if loaded
        except:
          from .tf_mcnn import crowd_counting
        model = crowd_counting(key)

###############################################
      else:
        log.log('not support model type ({})'.format(job['type']))
        self._model[key]['state'] = Model.State.NotSupport
        continue

      if model is not None:
        # init model necessary objects and start load
        self._model[key]['model'] = model
        self._model[key]['queue'] = queue.Queue()
        self._model[key]['state'] = model.load(key)
        if self._model[key]['state'] != Model.State.Loaded: continue

        # model loaded, start predictor thread
        threading.Thread(target=self._predictor, args=(key,), daemon=True).start()

        # 如果有 dummy 圖就預先 predict 一張，以加快後面的 predict 速度
        if dummy is not None and os.path.exists(dummy):
          self.predict(job['type'], job['name'], dummy, basedir=job['base'])
          log.log('{} predict dummy image done'.format(key))


  def _predictor(self, key):
    log.log('{} predict thread started'.format(key))
    while True:
      job = self._model[key]['queue'].get()
      job['reply'].put(self._model[key]['model'].predict(job['image']))


  #---------------------------------------------------------------------------
  # global function
  #---------------------------------------------------------------------------
  def load(self, modelType, modelName, basedir='models'):
    key = os.path.join(basedir, modelType, modelName)

    if not os.path.exists(key): 
      log.log('{} not exist'.format(key))
      return Model.State.NotExist.value # return 時傳 Enum value
    
    with self._loaderLock:
      if key not in self._model:
        log.log('enqueue {}'.format(key))
        self._model[key] = {}
        self._model[key]['state'] = Model.State.Queuing # 設狀態時傳 Enum object
        self._loaderQueue.put({
          'base': basedir,
          'type': modelType,
          'name': modelName,
          'key': key
        })

    return self._model[key]['state'].value


  def predict(self, modelType, modelName, imageFile, basedir='models'):
    key = os.path.join(basedir, modelType, modelName)

    if key not in self._model:
      log.log('{} not loaded'.format(key))
      return [Model.State.NotExist.value, None, None]

    if self._model[key]['state'] != Model.State.Loaded:
      log.log('{} state({}), is not loaded'.format(key, self._model[key]['state'].value))
      return [self._model[key]['state'].value, None, None]

    replyQueue = queue.Queue()
    self._model[key]['queue'].put({
      'image': imageFile,
      'reply': replyQueue
    })
    reply = replyQueue.get() # get block, wait for response
    del replyQueue
    return reply
    

  def clear(self):
    if self._tf():
      tf.compat.v1.reset_default_graph()
      # sess = ks.backend.get_session()
      # ks.backend.clear_session()
      # sess.close()
      # for k in list(self._model): # 用 list 會複製一份 loop 清單，才不會發生邊 loop 邊刪的錯誤
      #   with self._model[k]['graph'].as_default():
      #     with self._model[k]['session'].as_default():
      #       self._model[k]['session'].close()
      #       del self._model[k]['session']
      #     del self._model[k]['graph']
      #   del self._model[k]['model']
      #   del self._model[k]
      #   log.log('del model {}'.format(k))
      log.log(gc.collect())

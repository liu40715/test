import threading, inspect, datetime, os

class Log():
  def log(msg):
    try:
      stack = inspect.stack()
      print('{}, {}:{}, {}:{}:{}, {}'.format(
        datetime.datetime.utcnow().strftime('%Y/%m/%d %H:%M:%S.%f')[:-3],
        os.getpid(),
        threading.get_ident(),
        stack[1].filename,
        stack[1].function, 
        stack[1].lineno, 
        msg
      ))
    except UnicodeEncodeError:
      print('cimUtil.log catch UnicodeEncodeError.')
    except Exception as e:
      print('cimUtil.log catch an exception({}).'.format(e))
    finally:
      return msg

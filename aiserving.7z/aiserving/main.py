from cimUtil.log import Log as log
from cimAI.models import Models
import flask, json


#---------------------------------------------------------------------------
# flask
#---------------------------------------------------------------------------
models = None
app = flask.Flask(__name__)

# *************************************
# common function
# *************************************
def flaskJSONResponse(response):
  return flask.Response(
    json.dumps(response, indent=2).encode('utf-8'), 
    mimetype='application/json'
  )
    

# *************************************
# RESTful API
# *************************************
@app.route('/ai/load/<modelType>/<modelName>', methods=['POST'])
def aiLoad(modelType, modelName):
  try:
    return flaskJSONResponse({
      'type': modelType,
      'name': modelName,
      'state': models.load(modelType, modelName)
    })
  except Exception as e:
    return flaskJSONResponse({
      'type': modelType,
      'name': modelName,
      'state': log.log('{}'.format(e))
    })

@app.route('/ai/predict/<modelType>/<modelName>', methods=['POST'])
def aiPredict(modelType, modelName):
  try:
    # check HTTP form data
    if 'file' not in flask.request.files:
      return flaskJSONResponse({
        'type': modelType,
        'name': modelName,
        'state': 'no input image file'
      })

    state, b64Image, data = models.predict(modelType, modelName, flask.request.files["file"])
    return flaskJSONResponse({
      'type': modelType,
      'name': modelName,
      'state': state,
      'data': data,
      'base64': b64Image
    })
  except Exception as e:
    return flaskJSONResponse({
      'type': modelType,
      'name': modelName,
      'state': log.log('{}'.format(e))
    })

@app.route('/ai/clear', methods=['POST'])
def aiClear():
  try:
    models.clear()
    return flaskJSONResponse({
      'state': 'ok'
    })
  except Exception as e:
    return flaskJSONResponse({
      'state': log.log('{}'.format(e))
    })


# *************************************
# main
# *************************************
if __name__ == '__main__':
  models = Models()

  # start web service
  # debug=True flask 雖會自動在修改程式後 reload 方便 debug
  # 但會造成 process load 二次而發生 device/model 搶佔問題，所以這邊一律關掉
  #
  # 相關討論參考：
  # https://stackoverflow.com/questions/43644083/python-thread-running-twice-when-called-once-in-main
  # https://networklore.com/start-task-with-flask/
  app.run(host='0.0.0.0', port=80, debug=False, threaded=True)
  
import keras
from keras import backend as K
from nets.yolo import yolo_body
import keras2onnx
import onnx
from keras.models import load_model
model = yolo_body([608, 608, 3], [[6, 7, 8], [3, 4, 5], [0, 1, 2]], 80)
model.load_weights('./yolo4_weight.h5')
model.summary()
onnx_model = keras2onnx.convert_keras(model, model.name)
temp_model_file = './model.onnx'
onnx.save_model(onnx_model, temp_model_file)

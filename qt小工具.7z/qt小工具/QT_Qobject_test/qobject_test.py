import time,os,sys
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from view.qtui import Ui_MainWindow
import cv2
import numpy as np

class Threaded(QObject):
    result=pyqtSignal(int)
    def __init__(self, parent=None, **kwargs):
        super().__init__(parent=None, **kwargs)
    @pyqtSlot(int)
    def calculatePrime(self, n):
        print(n)
        self.result.emit(n)

class Threaded2(QObject):
    result2=pyqtSignal(str)
    def __init__(self, parent=None, **kwargs):
        super().__init__(parent=None, **kwargs)
    def start(self):
        start = "Thread started!!"
        print(start)
        self.result2.emit(start)
    @pyqtSlot(str)
    def calculatePrime(self, s):
        print(s)
        self.result2.emit(s)

class Threaded3(QObject):
    result3=pyqtSignal(QImage)
    def __init__(self, parent=None, **kwargs):
        super().__init__(parent=None, **kwargs)
    @pyqtSlot(str)
    def calculatePrime(self, s):
        try:
            frame = cv2.imread(s)
            cv2.imshow("image",frame)
            rgbImage = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            convertToQtFormat = QImage(rgbImage.data, rgbImage.shape[1], rgbImage.shape[0], QImage.Format_RGB888)
            time.sleep(3)##
            self.result3.emit(convertToQtFormat)
            cv2.waitKey(0)
        except:
            pass


cap = cv2.VideoCapture(0)
class Thread_cam(QThread):
    changePixmap = pyqtSignal(QImage)
    def __del__(self):
        self.wait()
    def run(self):
        while (True):
            ret, frame = cap.read()
            rgbImage = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            convertToQtFormat = QImage(rgbImage.data, rgbImage.shape[1], rgbImage.shape[0], QImage.Format_RGB888)
            self.changePixmap.emit(convertToQtFormat)

class mywindow(QtWidgets.QMainWindow,Ui_MainWindow):
    requestPrime=pyqtSignal(int)
    requestPrime2=pyqtSignal(str)
    requestPrime3=pyqtSignal(str)
    def __init__(self):
        super(mywindow, self).__init__()
        self.setupUi(self)
        self.event_link()

        self._threaded = Threaded(result=self.displayPrime)
        self.requestPrime.connect(self._threaded.calculatePrime)
        self._thread=QThread()
        self._threaded.moveToThread(self._thread)
        qApp.aboutToQuit.connect(self._thread.quit)
        self._thread.start()

        self._threaded2 = Threaded2(result2=self.displayPrime2)
        self.requestPrime2.connect(self._threaded2.calculatePrime)
        self._thread2=QThread()
        self._thread2.started.connect(self._threaded2.start)
        self._threaded2.moveToThread(self._thread2)
        qApp.aboutToQuit.connect(self._thread2.quit)
        self._thread2.start()

        self._threaded3 = Threaded3(result3=self.setImage)
        self.requestPrime3.connect(self._threaded3.calculatePrime)
        self._thread3=QThread()
        self._threaded3.moveToThread(self._thread3)
        qApp.aboutToQuit.connect(self._thread3.quit)
        self._thread3.start()

        self.th = Thread_cam(self)
        self.th.changePixmap.connect(self.setImage)

    def event_link(self):
        self.pushButton.clicked.connect(lambda:self.primeRequested())
        self.pushButton_2.clicked.connect(lambda:self.primeRequested2())
        self.pushButton_3.clicked.connect(lambda:self.primeRequested3())
##
##        self.pushButton_3.clicked.connect(lambda:self.cam())#Qthread WEBcam測試
##        self.pushButton.clicked.connect(lambda:self.stop())
    def primeRequested(self):
        try:
            a=int(self.lineEdit.text())
            b=int(self.lineEdit_2.text())
            c = a * b
        except:
            return
        self.requestPrime.emit(c)
        self.lineEdit.clear()
        self.lineEdit_2.clear()

    def primeRequested2(self):
        try:
            s = self.lineEdit_3.text()
        except:
            return
        self.requestPrime2.emit(s)
        self.lineEdit_3.clear()

    def primeRequested3(self):
        try:
            fileName, filetype = QFileDialog.getOpenFileName(self,  
            "選取檔案","./","Image Files (*.jpg);;All Files (*)")   
            self.Movie = QMovie('giphy.gif')  # 載入Gif圖，注意QMovie在PyQt5.QtCore內
            self.label_2.setMovie(self.Movie)
            self.Movie.start()
            self.progressBar.setRange(0,0)
        except:
            return
        self.requestPrime3.emit(fileName)

    @pyqtSlot(int)
    def displayPrime(self, prime):
        self.textEdit.clear()
        self.textEdit.append("Result: {}".format(prime))

    @pyqtSlot(str)
    def displayPrime2(self, s):
        self.textEdit.clear()
        self.textEdit.append(s)

    @pyqtSlot(QImage)
    def setImage(self, image):
        self.label_2.setPixmap(QPixmap.fromImage(image))
        self.progressBar.setRange(0,100)
        
    def cam(self):
        self.th.start()
        self.show()
    def stop(self):
        self.th.terminate()

def main():
    app = QtWidgets.QApplication(sys.argv)
    window = mywindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
